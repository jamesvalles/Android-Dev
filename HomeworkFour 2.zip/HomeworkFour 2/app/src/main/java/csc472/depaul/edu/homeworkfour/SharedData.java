package csc472.depaul.edu.homeworkfour;

public class SharedData
{
    private long time = 0L;
    private final static long TIME_INCREMENT = 1L;
    private double population = 7000000068d;
    private final static double POPULATION_INCREMENT = 2.37d;
    private static SharedData sharedData = null;

    static
    {
        sharedData = new SharedData();
    }

    private SharedData()
    {
    }

    public static SharedData getSharedData()
    {
        return sharedData;
    }

    /*
        @description - increments time by TIME_INCREMENT seconds
    */

    public void incrementTime()
    {
        time += TIME_INCREMENT;
    }

    /*
        @return long - seconds that have expired
     */

    public final long getTime()
    {
        return time;
    }

    /*
        @description - increments population by POPULATION_INCREMENT people
    */

    public void incrementPopulation()
    {
        population += POPULATION_INCREMENT;
    }

    /*
        @return double - world population
     */

    public final double getPopulation()
    {
        return population;
    }
}
