package afinal.csc472.depaul.edu.houseplants;

public enum Difficulty {
    EASY,
    AVERAGE,
    DIFFICULT
}
