package csc472.depaul.edu.homeworkfive;

public interface IInvestmentObserver
{
	public void investmentUpdate(int nthUpdate);
}
      