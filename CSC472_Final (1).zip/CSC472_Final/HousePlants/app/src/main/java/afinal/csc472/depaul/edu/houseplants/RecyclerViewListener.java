package afinal.csc472.depaul.edu.houseplants;

import android.view.View;

public interface RecyclerViewListener {
    void Click(View view, int position);
}
