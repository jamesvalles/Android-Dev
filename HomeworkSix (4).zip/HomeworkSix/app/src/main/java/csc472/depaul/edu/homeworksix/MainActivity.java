package csc472.depaul.edu.homeworksix;

//This is homework 7. Valles


import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.method.DigitsKeyListener;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {
    //TODO: You should create a model object for your channels and some logic to loop them
    private RemoteDisc remoteDisc;
    private final static int ONE_MEGABYTE_BUFFER = 1048576;//1MB
//   Television television;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("James Cable TV");



        //TODO: You need to set your contentView to your layout
        setContentView(R.layout.activity_main);

        //TODO: Map the remote disc control reference and set whatever object you choose as an observer

        //1 is for Portrait and 2 for Landscape
//        television = new Television(this);
        int orientation = getResources().getConfiguration().orientation;
        int portrait = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;

        if (orientation == portrait) {
            addRemoteController();
            addButtonController();
            addTelevisionController();
        } else {
            addRemoteController_Landscape();
            addButtonController_Landscape();
            addTelevisionController_Landscape();
        }

        File sdcard = Environment.getExternalStorageDirectory();
        File dir = new File(sdcard.getAbsolutePath() + "/csc472");
        File file = new File(dir + "/pin.txt");
        if (file.exists()) {
            enterPin();
        } else {
            createNewPin();
        }
    }


    //TODO: You can have the mainactiivty be the observer or even the buttons class


    //TODO: Once you decide where you want to handle the events you can catch the


    //TODO: up/down channel changes and have the buttons object respond accordingly


    private void addButtonController_Landscape() {
        LinearLayout left_pane = findViewById(R.id.activitymain_leftpane);
        if (left_pane != null) {

            LayoutInflater layoutInflater = LayoutInflater.from(this);
            LinearLayout buttonController = (LinearLayout) layoutInflater.inflate(R.layout.buttons, null);
            left_pane.addView(buttonController);

        }
    }

    private void addRemoteController_Landscape() {
        LinearLayout left_pane = findViewById(R.id.activitymain_leftpane);
        if (left_pane != null) {
            LayoutInflater layoutInflater = LayoutInflater.from(this);
            RemoteController remoteController = (RemoteController) layoutInflater.inflate(R.layout.remotedisc, null);
            left_pane.addView(remoteController);
            this.remoteDisc = remoteController.getRemoteDisc();
        }
    }

    private void addTelevisionController_Landscape() {
        LinearLayout right_pane = findViewById(R.id.activitymain_rightpane);
        if (right_pane != null) {
            LayoutInflater layoutInflater = LayoutInflater.from(this);
            TelevisonController televisonController = (TelevisonController) layoutInflater.inflate(R.layout.television, null);
            right_pane.addView(televisonController);
            Television television = televisonController.getTelevision();
            this.remoteDisc.setRemoteDiscObserver(television);
        }
    }

    private void addButtonController() {
        LinearLayout main_pane = findViewById(R.id.activitymain_pane);
        if (main_pane != null) {

            LayoutInflater layoutInflater = LayoutInflater.from(this);
            LinearLayout buttonController = (LinearLayout) layoutInflater.inflate(R.layout.buttons, null);
            main_pane.addView(buttonController);

        }
    }

    private void addRemoteController() {
        LinearLayout main_pane = findViewById(R.id.activitymain_pane);
        if (main_pane != null) {
            LayoutInflater layoutInflater = LayoutInflater.from(this);
            RemoteController discController = (RemoteController) layoutInflater.inflate(R.layout.remotedisc, null);
            main_pane.addView(discController);
            this.remoteDisc = discController.getRemoteDisc();
        }
    }

    private void addTelevisionController() {
        LinearLayout main_pane = findViewById(R.id.activitymain_pane);
        if (main_pane != null) {
            LayoutInflater layoutInflater = LayoutInflater.from(this);
            TelevisonController televisonController = (TelevisonController) layoutInflater.inflate(R.layout.television, null);
            main_pane.addView(televisonController);
            Television television = televisonController.getTelevision();
            this.remoteDisc.setRemoteDiscObserver(television);
        }
    }


//    @Override
//    public void onSaveInstanceState(Bundle savedInstanceState) {
//        super.onSaveInstanceState(savedInstanceState);
//        int index = television.getLineupIndex();
//        savedInstanceState.putInt("Index", index);
//
//    }
//
//    @Override
//    public void onRestoreInstanceState(Bundle savedInstanceState) {
//        super.onRestoreInstanceState(savedInstanceState);
//        Bundle bundle = savedInstanceState.getBundle("Index");
//        int index = bundle.getInt("Index");
//        television.setLineupIndex(index);
//    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        //TODO: dont' forget to stop observing (set it to null) if you setup an observer on the remote disc
    }


    private void createNewPin() {
        final EditText pin = new EditText(this);
        pin.setHint("****");
        pin.setTextSize(24);
        pin.setTypeface(null, Typeface.BOLD);
        pin.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        pin.setFilters(new InputFilter[]{
                // Maximum 2 characters.
                new InputFilter.LengthFilter(4),
        });
        // Digits only & use numeric soft-keyboard.
        pin.setKeyListener(DigitsKeyListener.getInstance(Locale.getDefault()));

        final TextView pinTitle = new TextView(this);
        pinTitle.setText(getResources().getString(R.string.create_new_pin));
        pinTitle.setTextSize(24);
        pinTitle.setTypeface(null, Typeface.BOLD);
        pinTitle.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        final AlertDialog createPin = new AlertDialog.Builder(this)
                .setCustomTitle(pinTitle)
                .setView(pin)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    }
                })
                .setOnKeyListener(new DialogInterface.OnKeyListener() {
                    @Override
                    public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                        if (keyCode == KeyEvent.KEYCODE_ENTER) {
                            if (pin.getText().length() == 4) {
                                dialog.dismiss();
                                saveNewPin(pin.getText().toString());
                            }
                        }

                        return false;
                    }
                }).create();
        createPin.show();

        createPin.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pin.getText().length() == 4) {
                    createPin.dismiss();
                    saveNewPin(pin.getText().toString());
                }
            }
        });

        createPin.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

        createPin.show();
    }


    private void saveNewPin(final String uncryptedtext) {
        try {

            requestWriteToExternalStoragePermission();

            File sdCard = Environment.getExternalStorageDirectory();
            File dir = new File(sdCard.getAbsolutePath() + "/csc472");
            dir.mkdirs();

            File file = new File(dir + "/pin.txt");
            file.createNewFile();
            String encryptedata = Cryption.getCryption().aes256Encrypt(uncryptedtext, uncryptedtext);
            FileOutputStream outputFile = new FileOutputStream(file);
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputFile);
            outputStreamWriter.append(encryptedata);
            outputStreamWriter.close();
            outputFile.close();

        } catch (Exception e) {
        }
    }

    public MainActivity getMainActivity() {
        return this;
    }

    private void requestWriteToExternalStoragePermission() {
        int writePermission = ActivityCompat.checkSelfPermission(getMainActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (writePermission != PackageManager.PERMISSION_GRANTED) {
            int REQUEST_EXTERNAL_STORAGE = 1;

            String[] PERMISSIONS_STORAGE = {
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            };

            ActivityCompat.requestPermissions(
                    getMainActivity(),
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }


    private void enterPin() {
        final EditText pin = new EditText(this);
        pin.setHint("****");
        pin.setTextSize(24);
        pin.setTypeface(null, Typeface.BOLD);
        pin.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        pin.setFilters(new InputFilter[]{
                // Maximum 2 characters.
                new InputFilter.LengthFilter(4),
        });
        // Digits only & use numeric soft-keyboard.
        pin.setKeyListener(DigitsKeyListener.getInstance(Locale.getDefault()));

        final TextView pinTitle = new TextView(this);
        pinTitle.setText(getResources().getString(R.string.enter_existing_pin));
        pinTitle.setTextSize(24);
        pinTitle.setTypeface(null, Typeface.BOLD);
        pinTitle.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        final AlertDialog createPin = new AlertDialog.Builder(this)
                .setCustomTitle(pinTitle)
                .setView(pin)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    }
                })
                .setOnKeyListener(new DialogInterface.OnKeyListener() {
                    @Override
                    public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                        if (keyCode == KeyEvent.KEYCODE_ENTER) {
                            if (pin.getText().length() == 4) {
                                dialog.dismiss();
                               verifyPin(pin.getText().toString());
                            }
                        }

                        return false;
                    }
                }).create();
        createPin.show();

        createPin.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pin.getText().length() == 4) {
                    createPin.dismiss();
                    verifyPin(pin.getText().toString());
                }
            }
        });

        createPin.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

        createPin.show();
    }

    private void verifyPin(final String uncryptedtext) {
        try {
            File sdCard = Environment.getExternalStorageDirectory();
            File dir = new File(sdCard.getAbsolutePath() + "/csc472");
            File file = new File(dir + "/pin.txt");

            InputStream inputStream = new FileInputStream(file);
            InputStreamReader isr = new InputStreamReader(inputStream);
            BufferedReader in = new BufferedReader(isr);

            String inputLine;

            StringBuilder stringBuilder = null;

            try {
                stringBuilder = new StringBuilder(ONE_MEGABYTE_BUFFER);

            } catch (OutOfMemoryError outOfMemoryError) {
                stringBuilder = new StringBuilder();
            }

            while ((inputLine = in.readLine()) != null) {
                stringBuilder.append(inputLine);
            }
            in.close();

            String decryptedtext = Cryption.getCryption().aes256Decrypt(uncryptedtext, stringBuilder.toString());
            if (decryptedtext == null) {
                Toast toast = Toast.makeText(getMainActivity(), "Sorry, password Incorrect. Try Again.", Toast.LENGTH_LONG);
                toast.show();
                enterPin();
            }
            if (decryptedtext.equals(uncryptedtext)) {
                Toast toast = Toast.makeText(getMainActivity(), "Yay, password correct. Enjoy James TV!", Toast.LENGTH_LONG);
                toast.show();
                return;
            }

        } catch (Exception ex) {

        }
    }
}