package csc472.depaul.edu.homeworksix;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    //TODO: You should create a model object for your channels and some logic to loop them
    private RemoteDisc remoteDisc;
//   Television television;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("James Cable TV");

        //TODO: You need to set your contentView to your layout
        setContentView(R.layout.activity_main);

        //TODO: Map the remote disc control reference and set whatever object you choose as an observer

        //1 is for Portrait and 2 for Landscape
//        television = new Television(this);
        int orientation = getResources().getConfiguration().orientation;
        int portrait = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;

        if (orientation == portrait) {
            addRemoteController();
            addButtonController();
            addTelevisionController();
        } else {
            addRemoteController_Landscape();
            addButtonController_Landscape();
            addTelevisionController_Landscape();
        }

        //TODO: You can have the mainactiivty be the observer or even the buttons class


        //TODO: Once you decide where you want to handle the events you can catch the


        //TODO: up/down channel changes and have the buttons object respond accordingly
    }

    private void addButtonController_Landscape() {
        LinearLayout left_pane = findViewById(R.id.activitymain_leftpane);
        if (left_pane != null) {

            LayoutInflater layoutInflater = LayoutInflater.from(this);
            LinearLayout buttonController = (LinearLayout) layoutInflater.inflate(R.layout.buttons, null);
            left_pane.addView(buttonController);

        }
    }

    private void addRemoteController_Landscape() {
        LinearLayout left_pane = findViewById(R.id.activitymain_leftpane);
        if (left_pane != null) {
            LayoutInflater layoutInflater = LayoutInflater.from(this);
            RemoteController remoteController = (RemoteController) layoutInflater.inflate(R.layout.remotedisc, null);
            left_pane.addView(remoteController);
            this.remoteDisc = remoteController.getRemoteDisc();
        }
    }

    private void addTelevisionController_Landscape() {
        LinearLayout right_pane = findViewById(R.id.activitymain_rightpane);
        if (right_pane != null) {
            LayoutInflater layoutInflater = LayoutInflater.from(this);
            TelevisonController televisonController = (TelevisonController) layoutInflater.inflate(R.layout.television, null);
            right_pane.addView(televisonController);
            Television television = televisonController.getTelevision();
            this.remoteDisc.setRemoteDiscObserver(television);
        }
    }


    private void addButtonController() {
        LinearLayout main_pane = findViewById(R.id.activitymain_pane);
        if (main_pane != null) {

            LayoutInflater layoutInflater = LayoutInflater.from(this);
            LinearLayout buttonController = (LinearLayout) layoutInflater.inflate(R.layout.buttons, null);
            main_pane.addView(buttonController);

        }
    }

    private void addRemoteController() {
        LinearLayout main_pane = findViewById(R.id.activitymain_pane);
        if (main_pane != null) {
            LayoutInflater layoutInflater = LayoutInflater.from(this);
            RemoteController discController = (RemoteController) layoutInflater.inflate(R.layout.remotedisc, null);
            main_pane.addView(discController);
            this.remoteDisc = discController.getRemoteDisc();
        }
    }

    private void addTelevisionController() {
        LinearLayout main_pane = findViewById(R.id.activitymain_pane);
        if (main_pane != null) {
            LayoutInflater layoutInflater = LayoutInflater.from(this);
            TelevisonController televisonController = (TelevisonController) layoutInflater.inflate(R.layout.television, null);
            main_pane.addView(televisonController);
            Television television = televisonController.getTelevision();
            this.remoteDisc.setRemoteDiscObserver(television);
        }
    }


//    @Override
//    public void onSaveInstanceState(Bundle savedInstanceState) {
//        super.onSaveInstanceState(savedInstanceState);
//        int index = television.getLineupIndex();
//        savedInstanceState.putInt("Index", index);
//
//    }
//
//    @Override
//    public void onRestoreInstanceState(Bundle savedInstanceState) {
//        super.onRestoreInstanceState(savedInstanceState);
//        Bundle bundle = savedInstanceState.getBundle("Index");
//        int index = bundle.getInt("Index");
//        television.setLineupIndex(index);
//    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        //TODO: dont' forget to stop observing (set it to null) if you setup an observer on the remote disc
    }
}
