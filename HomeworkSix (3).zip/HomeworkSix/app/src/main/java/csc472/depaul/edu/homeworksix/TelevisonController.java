package csc472.depaul.edu.homeworksix;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.LinearLayout;

public class TelevisonController extends LinearLayout {

    private Television television;

    public TelevisonController(Context context) {
        super(context);
        addInflatorLayout(context);
    }

    public TelevisonController(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        addInflatorLayout(context);
    }

    public TelevisonController(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        addInflatorLayout(context);
    }

    private void addInflatorLayout(Context context) {
        TelevisonController.LayoutParams params = new TelevisonController.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.width = ViewGroup.LayoutParams.WRAP_CONTENT;
        params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        params.bottomMargin = 5;
        setLayoutParams(params);
        television = new Television(context);
        addView(television);
    }

    public Television getTelevision() {
        return television;
    }
}
