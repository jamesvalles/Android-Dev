package csc472.depaul.edu.homeworkfour;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HomeworkFourActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.homework_four_activity);

        Button timeActivity = findViewById(R.id.timeActivity);
        if (timeActivity != null)
        {
            timeActivity.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    //This will start the TimeActivity
                    Intent intent = new Intent(getMainActivity(), TimeActivity.class);
                    getMainActivity().startActivity(intent);
                }
            });
        }

        Button populationActivity = findViewById(R.id.populationActivity);
        if (populationActivity != null)
        {
            populationActivity.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    //This will start the PopulationActivity
                    Intent intent = new Intent(getMainActivity(), PopulationActivity.class);
                    getMainActivity().startActivity(intent);
                }
            });
        }

        //TODO: Uncomment this to see what thread is running
        //main thread is running here
        Log.v("THREAD_NAME : HomeworkFourActivity: onCreate", Thread.currentThread().getName());
    }

    @Override
    protected void onResume()
    {
        super.onResume();

        TextView time = findViewById(R.id.time);
        if (time != null)
        {
            long newTime = SharedData.getSharedData().getTime();

            time.setText(String.format("%02d:%02d", newTime / 60, newTime % 60));
        }

        TextView population = findViewById(R.id.population);
        if (population != null)
        {
            double newPopulation = SharedData.getSharedData().getPopulation();

            population.setText(String.format("%d", (long)newPopulation));
        }

        //TODO: Uncomment this to see what thread is running
        //mainthread is running here
        Log.v("THREAD_NAME : HomeworkFourActivity: onResume", Thread.currentThread().getName());
    }


    private HomeworkFourActivity getMainActivity()
    {
        return this;
    }
}
