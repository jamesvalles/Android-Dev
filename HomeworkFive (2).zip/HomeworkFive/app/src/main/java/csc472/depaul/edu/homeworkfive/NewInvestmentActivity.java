    package csc472.depaul.edu.homeworkfive;

    import android.content.Intent;
    import android.os.Bundle;
    import android.support.v7.app.AppCompatActivity;
    import android.view.View;
    import android.widget.Button;
    import android.widget.EditText;
    import android.widget.Toast;

    public class NewInvestmentActivity extends AppCompatActivity {
        private final static float MIN_RATE = 0.001f;
        //****Old code***
        //    private EditText eName;
        //    private EditText eInvest;
        //    private EditText eRate;
        //****Old code***

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.new_investment_activity);

            final Button invest = findViewById(R.id.invest);
            if (invest != null) {
                invest.setOnClickListener(onClickInvest);
            }

        //****Old code***
        //        eName = findViewById(R.id.name);
        //        eInvest = findViewById(R.id.investment);
        //        eRate = findViewById(R.id.rate);
        //****Old code***
        }

        private final NewInvestmentActivity getNewUserActivity() {
            return this;
        }

        private View.OnClickListener onClickInvest = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((validateEditTextField(R.id.rate)) && (validateEditTextField(R.id.name)) && (validateEditTextField(R.id.investment))) {
                    final EditText rate = findViewById(R.id.rate);
                    if (rate != null) {
                        float fRate = Float.valueOf(rate.getText().toString());
                        if (fRate >= MIN_RATE) {
                            //TODO: You can use the following values to create your Investment object

                            String sName = getEditViewText(R.id.name);
                            String sInitial = getEditViewText(R.id.investment);
                            float fInitial = Float.valueOf(sInitial);

                            //CREATE INVESTMENT OBJECT
                            Investment investment = new Investment(sName, fInitial, fRate);

                            //TODO: Launch InvestmentActivity via INTENT mechanism with your Investment object packed into the bundle.

                            //CREATE NEW INTENT
                            Intent intent = new Intent(NewInvestmentActivity.this, InvestmentActivity.class);

                            //STORING OBJECT IN INTENT
                            intent.putExtra("InvestObject", investment);

                            //  Bundle bundle = new Bundle();
                            //  bundle.putString("Name", sName);
                            //  bundle.putFloat("Investment", fInitial);
                            //  bundle.putFloat("Rate", fRate);

                            //START ACTIVITY
                            startActivity(intent);

                            //TODO: Make sure the model classes can be properly serialized/deserialized.
                            //TODO: You should implement Parcelable interface your models.
                        } else {
                            String sToastMessage = getResources().getString(R.string.rate_too_low);
                            Toast toast = Toast.makeText(getApplicationContext(), sToastMessage, Toast.LENGTH_LONG);
                            toast.show();
                        }
                    }
                }
            }
        };


        //helper functions below
        private boolean validateEditTextField(int id) {
            boolean isValid = false;

            final EditText editText = findViewById(id);
            if (editText != null) {
                String sText = editText.getText().toString();

                isValid = ((sText != null) && (!sText.isEmpty()));
            }

            if (!isValid) {
                String sToastMessage = getResources().getString(R.string.fields_cannot_be_empty);
                Toast toast = Toast.makeText(getApplicationContext(), sToastMessage, Toast.LENGTH_LONG);
                toast.show();
            }

            return isValid;
        }

        private final String getEditViewText(int id) {
            String sText = "";

            final EditText editText = findViewById(id);
            if (editText != null) {
                sText = editText.getText().toString();
            }

            return sText;
        }

        //***OLD CODE*****
        //    @Override
        //    protected void onSaveInstanceState(Bundle savedInstanceState){
        //        super.onSaveInstanceState(savedInstanceState);
        //
        //        String saveName = eName.getText().toString();
        //        String saveInvest = eInvest.getText().toString();
        //        String saveRate = eRate.getText().toString();
        //
        //        savedInstanceState.putString("Name", saveName);
        //        savedInstanceState.putString("Investment", saveInvest);
        //        savedInstanceState.putString("Rate", saveRate);
        //    }

        //    @Override
        //    protected void onRestoreInstanceState(Bundle savedInstanceState){
        //        super.onRestoreInstanceState(savedInstanceState);
        //        eName.setText(savedInstanceState.getString("Name"));
        //        eInvest.setText(savedInstanceState.getString("Investment"));
        //        eRate.setText(savedInstanceState.getString("Rate"));
        //    }
        //***OLD CODE*****
    }
