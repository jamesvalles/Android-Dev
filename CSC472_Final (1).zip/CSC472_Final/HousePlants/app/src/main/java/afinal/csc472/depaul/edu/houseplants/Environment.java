package afinal.csc472.depaul.edu.houseplants;

public enum  Environment {
    yes,
    no
}
