package csc472.depaul.edu.homeworkfour;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class TimeActivity extends AppCompatActivity
{
    public static TextView time = null;//a global static variable

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        //TODO: Uncomment this to see what thread is running
        //Log.v("THREAD_NAME : TimeActivity: onCreate", Thread.currentThread().getName());

        super.onCreate(savedInstanceState);
        setContentView(R.layout.time_activity);

        final Button startTime = findViewById(R.id.startTimeCount);
        if (startTime != null)
        {
            startTime.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    startTimeCount();
                }
            });
        }

        time = findViewById(R.id.time);
        if (time != null)
        {
            time.setText(Long.toString(SharedData.getSharedData().getTime()));
        }
    }

    private void startTimeCount()
    {
        TimeThread.getTimeThread().start();
    }

    public static void timeUpdated()
    {
        //TODO: Look at the thread name that is being logged - is it the main thread?
        //remember 'public' and static methods can easily be executed from any thread.
        //static methods can be executed any time without needing to be instantiated.

        //TODO: Uncomment this to see what thread is running
         //running time thread
         Log.v("THREAD_NAME : TimeActivity: timeUpdated", Thread.currentThread().getName());


        //put a break point here - open your debug pane - go to debugger / threads
        //what thread is executing?
        if (time != null)
        {
            //TODO: Issue #3 What thread is executing?  Is it the main thread? Is this legal?
          //  time.setText(Long.toString(SharedData.getSharedData().getTime()));
        }

        //TODO: Issue #4 At this point what thread is executing? \
        //The method below will ENSURE we are on the main thread but you'll need to step into it to fix it
        updateTimeOnMainThread();
    }

    private static void updateTimeOnMainThread()
    {
        //TODO: Uncomment the code below and look at the thread name that is being logged - we are still on 'TimeThread'
        // Log.v("THREAD_NAME: TimeActivity: updateTimeOnMainThread", Thread.currentThread().getName());

        //TODO: Issue #5 : This will trigger a message on the main thread/queue - uncoment and give it a try
        mainThreadHandler.sendEmptyMessage(0);
    }

    public static Handler mainThreadHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            //TODO: Uncomment the code below look at the thread name that is being logged - is it the main thread?
             Log.v("THREAD_NAME: TimeActivity: mainThreadHandler", Thread.currentThread().getName());

            //the line below will set your text
            time.setText(Long.toString(SharedData.getSharedData().getTime()));
        }
    };
}
