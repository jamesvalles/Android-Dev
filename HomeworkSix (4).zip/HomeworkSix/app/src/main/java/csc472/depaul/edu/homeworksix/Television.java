package csc472.depaul.edu.homeworksix;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class Television extends android.support.v7.widget.AppCompatImageView implements IRemoteDiscObserver {

    private ArrayList<Integer> channelLineup = new ArrayList<>();
    private int lineupIndex = 0;

    public Television(Context context) {
        super(context);
        setProgram();
    }

    public Television(Context context, AttributeSet attrs) {
        super(context, attrs);
        setProgram();
    }

    public Television(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setProgram() {
        channelLineup.add(R.drawable.cartoons);
        channelLineup.add(R.drawable.educational);
        channelLineup.add(R.drawable.sports);
        setBackgroundResource(channelLineup.get(0));
    }

    @Override
    public void channelDown() {
        if (lineupIndex == 0) {
            setBackgroundResource(channelLineup.get(2));
            saveCurrentChannel(Integer.toString(2));
            lineupIndex = 2;
        } else {
            setBackgroundResource(channelLineup.get(--lineupIndex));
            saveCurrentChannel(Integer.toString(this.lineupIndex));
        }
    }

    public void setLineupIndex(int lineupIndex) {
        this.lineupIndex = lineupIndex;
    }

    public int getLineupIndex() {

        return lineupIndex;
    }

    @Override
    public void channelUp() {
        if (lineupIndex == 2) {
            setBackgroundResource(channelLineup.get(0));
            saveCurrentChannel(Integer.toString(0));
            lineupIndex = 0;
        } else {
            setBackgroundResource(channelLineup.get(++lineupIndex));
            saveCurrentChannel(Integer.toString(this.lineupIndex));
        }

    }

    @Override
    public void volumeDown() {
        String text = "Volume: Down";
        Toast toast = Toast.makeText(getContext(), text, Toast.LENGTH_SHORT);
        toast.show();
    }

    @Override
    public void volumeUp() {
        String text = "Volume: Up";
        Toast toast = Toast.makeText(getContext(), text, Toast.LENGTH_SHORT);
        toast.show();
    }

    private void saveCurrentChannel(String current) {
        SharedPreferences sharedPreferences = this.getContext().getSharedPreferences("REMOTE_SETTINGS", Activity.MODE_PRIVATE);

        if (sharedPreferences != null) {
            String sValue = sharedPreferences.getString("Channel: ", null);
            if (sValue != null) {
                SharedPreferences.Editor channelEditor = sharedPreferences.edit();
                if (channelEditor != null) {
                    channelEditor.putString("Channel: ", current);
                    channelEditor.commit();
                }
                Toast toast = Toast.makeText(this.getContext(), "Channel " + sValue + " saved to preferences.", Toast.LENGTH_SHORT);
                toast.show();
            } else {
                SharedPreferences.Editor channelEditor = sharedPreferences.edit();
                if (channelEditor != null) {
                    channelEditor.putString("Channel: ", "0");
                    channelEditor.commit();
                }
                Toast toast = Toast.makeText(this.getContext(), "Channel " + sValue + " saved to preferences.", Toast.LENGTH_SHORT);
                toast.show();
            }
        }
    }
}
