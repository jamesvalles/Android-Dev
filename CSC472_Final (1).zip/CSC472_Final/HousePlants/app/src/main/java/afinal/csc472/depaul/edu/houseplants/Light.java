package afinal.csc472.depaul.edu.houseplants;

public enum Light {
    LOW,
    MEDIUM,
    HIGH
}
