package csc472.depaul.edu.homeworksix;

import android.content.Context;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class Television extends android.support.v7.widget.AppCompatImageView implements IRemoteDiscObserver {

    private ArrayList<Integer> channelLineup = new ArrayList<>();
    private int lineupIndex = 0;

    public Television(Context context) {
        super(context);
        setProgram();
    }

    public Television(Context context, AttributeSet attrs) {
        super(context, attrs);
        setProgram();
    }

    public Television(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setProgram() {
        channelLineup.add(R.drawable.cartoons);
        channelLineup.add(R.drawable.educational);
        channelLineup.add(R.drawable.sports);
        setBackgroundResource(channelLineup.get(0));
    }

    @Override
    public void channelDown() {
        if (lineupIndex == 0) {
            setBackgroundResource(channelLineup.get(2));
            lineupIndex = 2;
        } else {
            setBackgroundResource(channelLineup.get(--lineupIndex));
        }
    }

    public void setLineupIndex(int lineupIndex) {
        this.lineupIndex = lineupIndex;
    }

    public int getLineupIndex() {

        return lineupIndex;
    }

    @Override
    public void channelUp() {
        if (lineupIndex == 2) {
            setBackgroundResource(channelLineup.get(0));
            lineupIndex = 0;
        } else {
            setBackgroundResource(channelLineup.get(++lineupIndex));
        }

    }

    @Override
    public void volumeDown() {
        String text = "Volume: Down";
        Toast toast = Toast.makeText(getContext(), text, Toast.LENGTH_SHORT);
        toast.show();
    }

    @Override
    public void volumeUp() {
        String text = "Volume: Up";
        Toast toast = Toast.makeText(getContext(), text, Toast.LENGTH_SHORT);
        toast.show();
    }
}
