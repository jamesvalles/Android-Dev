# HappyPlants

## Are you a fan of raising succulent plant?

## Have you ever wonder why the plant you raise always dead?

## Do you want to share your experience of raising a plant with your friend?

I want to develop an application that can help people who are interested in raising plants but have no time to take care of them. The app will:

1. Ask several questions to user to determine a plant they want to raise

2. Pull out specific plant raising related data from open source API and render on UI.

3. Set time clock to notice user to water the plant.

4. keep track of temperature if possible.

The app will also leverage android api such as,

1. Call camera to take picture.

2. Clock to track the time.

3. maybe monitoring the temperature and light intensity.

4. Link with instagram, facebook or twitter.

5. Auto generate timeline of your raising history.

## Weekly Log
### Week 1
*Work on setting up project, completing UI, work with getting data from API parsed and database setup.

UI Assignments

Harry’s UI
Login
Shared-facebook
Home (bottom bar)
garden（card)

Sally’s UI
Questions 1-4

James’ UI
your suggestions
More about suggestions
about this plant
Welcome@3x

//james has committed

//Sally's random commits 1

//Harry has committed 1

//test for pull to own branch