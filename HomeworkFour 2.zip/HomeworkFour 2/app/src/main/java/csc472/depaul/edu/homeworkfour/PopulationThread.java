package csc472.depaul.edu.homeworkfour;

import android.util.Log;

import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class PopulationThread implements Runnable
{
	private boolean started  = false;
	private static PopulationThread populationThread = null;

	static
	{
		populationThread = new PopulationThread();
	}

	private PopulationThread()
	{
	}

	public static PopulationThread getPopulationThread()
	{
		return populationThread;
	}

	public synchronized void start()
	{
		//TODO: Uncomment the code below look at the thread name that is being logged - is it the main thread?
		//Yes, it is main thread.
		 Log.v("THREAD_NAME: PopulationThread: start", Thread.currentThread().getName());

		if (started == false)
		{
			started = true;

			ScheduledThreadPoolExecutor scheduler = new ScheduledThreadPoolExecutor(1, new NamedThreadFactory("PopulationThread"));
			if (scheduler != null)
			{
				scheduler.scheduleAtFixedRate(this, 0, 1, TimeUnit.SECONDS);
			}
		}
	}

	@Override
	public void run()
	{
		//TODO: Uncomment the code below look at the thread name that is being logged - is it the main thread?
		//no. it is the population thread.
		 Log.v("THREAD_NAME: PopulationThread: run", Thread.currentThread().getName());

		try
		{
			SharedData.getSharedData().incrementPopulation();

			//TODO: Issue #1 - time is an UI element it needs updated on the main thread
			//TODO: Is this call legal?  If not you should delete it and find another way!
			//PopulationActivity.population.setText(Long.toString((long)SharedData.getSharedData().getPopulation()));


			//TODO: Issue #2 -  if the above call is illegal then try calling a method in the time activity
			//TODO: to better understand what thread is running - you can use the one below
			PopulationActivity.populationUpdated();
		}
		catch (Exception e)
		{
			Log.e("THREAD_NAME: PopulationActivity: run", e.getMessage());
		}
	}
}

