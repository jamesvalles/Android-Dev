package csc472.depaul.edu.homeworkfive;

import android.os.Parcel;
import android.os.Parcelable;

//ADD PARCELABLE INTERFACE TO CLASS
public final class Investment implements Parcelable
{
    private String  name           = null;
    private Balance initialBalance = null;
    private Balance currentBalance = null;
    private Rate    rate           = null;

    public Investment(final String sName, final Float fInitialBalance, final Float fRate)
    {
        name           = new String (sName);
        initialBalance = new Balance(fInitialBalance);
        currentBalance = new Balance(fInitialBalance);
        rate           = new Rate   (fRate);
    }

    /*
        @param dCurrentBalance - the current balance of the investment
    */

    protected Investment(Parcel in) {
        name = in.readString();
        initialBalance = in.readParcelable(Balance.class.getClassLoader());
        currentBalance = in.readParcelable(Balance.class.getClassLoader());
        rate = in.readParcelable(Rate.class.getClassLoader());
    }

    public static final Creator<Investment> CREATOR = new Creator<Investment>() {
        @Override
        public Investment createFromParcel(Parcel in) {
            return new Investment(in);
        }

        @Override
        public Investment[] newArray(int size) {
            return new Investment[size];
        }
    };

    public void setCurrentBalance(final Float fCurrentBalance)
    {
        currentBalance = new Balance(fCurrentBalance);
    }

    /*
        @return name - the name of the investment
     */

    public final String getName()
    {
        return name;
    }

    /*
        @return initialBalance - the initial balance of the investment
     */

    public final Balance getInitialBalance()
    {
        return initialBalance;
    }

    /*
        @return currentBalance - the current balance of the investment
     */

    public final Balance getCurrentBalance()
    {
        return currentBalance;
    }

    /*
        @return rate - the rate of the investment
     */

    public final Rate getRate()
    {
        return rate;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeParcelable(initialBalance, flags);
        dest.writeParcelable(currentBalance, flags);
        dest.writeParcelable(rate, flags);
    }
}
