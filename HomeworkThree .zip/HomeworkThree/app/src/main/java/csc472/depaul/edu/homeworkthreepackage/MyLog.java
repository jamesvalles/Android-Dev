package csc472.depaul.edu.homeworkthreepackage;

import android.util.Log;

public class MyLog {


    public static void d(String text){
        if(BuildConfig.FLAVOR.equals("withlog")){
            Log.d("HomeworkThree", text);
        }
        else{

        }
    }
}
