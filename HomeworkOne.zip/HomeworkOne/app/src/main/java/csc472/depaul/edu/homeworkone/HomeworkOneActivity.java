package csc472.depaul.edu.homeworkone;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class HomeworkOneActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homework_one);

        Log.d("HomeworkOneActivity", "onCreate called");

        //TODO: Learn about onCreate soon
    }
}
