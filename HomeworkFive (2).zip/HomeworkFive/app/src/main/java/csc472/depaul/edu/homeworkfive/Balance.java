package csc472.depaul.edu.homeworkfive;

import android.os.Parcel;
import android.os.Parcelable;

//ADD PARCELABLE INTERFACE TO CLASS
public final class Balance implements Parcelable
{
    private Float balance = 0.0f;

    public Balance(final Float fBalance)
    {
        balance = fBalance;
    }

    /*
        @param newBalance - the new balance of the investment
    */

    protected Balance(Parcel in) {
        if (in.readByte() == 0) {
            balance = null;
        } else {
            balance = in.readFloat();
        }
    }

    public static final Creator<Balance> CREATOR = new Creator<Balance>() {
        @Override
        public Balance createFromParcel(Parcel in) {
            return new Balance(in);
        }

        @Override
        public Balance[] newArray(int size) {
            return new Balance[size];
        }
    };

    public void setBalance(final Float fBalance)
    {
        balance = fBalance;
    }

    /*
        @return balance - the balance of the investment
     */

    public final Float getBalance()
    {
        return balance;
    }

    @Override
    public final String toString()
    {
        return Float.toString(balance);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        if (balance == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeFloat(balance);
        }
    }
}
