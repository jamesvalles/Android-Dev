package csc472.depaul.edu.homeworksix;

public interface IRemoteDiscObserver
{
	void channelDown();
	void channelUp();
	void volumeDown();
	void volumeUp();
}
      