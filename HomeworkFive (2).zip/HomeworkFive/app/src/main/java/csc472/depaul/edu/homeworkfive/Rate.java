package csc472.depaul.edu.homeworkfive;

import android.os.Parcel;
import android.os.Parcelable;

//ADD PARCELABLE INTERFACE TO CLASS
public final class Rate implements Parcelable
{
    private Float rate = 0.0f;

    public Rate(final Float fInitialRate)
    {
        rate = fInitialRate;
    }

    //read only pattern - no setters

    /*
        @return rate - the rate of the investment
     */

    protected Rate(Parcel in) {
        if (in.readByte() == 0) {
            rate = null;
        } else {
            rate = in.readFloat();
        }
    }

    public static final Creator<Rate> CREATOR = new Creator<Rate>() {
        @Override
        public Rate createFromParcel(Parcel in) {
            return new Rate(in);
        }

        @Override
        public Rate[] newArray(int size) {
            return new Rate[size];
        }
    };

    public final Float getRate()
    {
        return rate;
    }

    @Override
    public final String toString()
    {
        return rate.toString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        if (rate == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeFloat(rate);
        }
    }
}
