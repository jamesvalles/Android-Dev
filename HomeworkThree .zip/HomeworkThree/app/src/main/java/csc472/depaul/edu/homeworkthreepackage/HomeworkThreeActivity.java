package csc472.depaul.edu.homeworkthreepackage;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class HomeworkThreeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homework_three);

       MyLog.d("onCreate: This will show if Build Variant withlog is selected.");
    }
}
