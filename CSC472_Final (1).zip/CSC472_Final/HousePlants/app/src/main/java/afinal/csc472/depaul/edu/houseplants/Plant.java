package afinal.csc472.depaul.edu.houseplants;

public enum Plant {
//    Bonsai
    ChineseElm,
    Jade,
    FicusRetusa,
    JapaneseMaple,
//    Clean aire
    Bamboo,
    Evergreen,//hanging
    Spider,//hanging
    MassCane,
//    Ground
    GroundIvy,
    CreepingDogwood,
    ChristmasFern,//hanging
//    Flowing,
    Satsuki,//office
    DehliaTubers,
    Cactus, //office
    WizardMix,
// hanging
    ceropegia,
    DevilIvy//office

}
