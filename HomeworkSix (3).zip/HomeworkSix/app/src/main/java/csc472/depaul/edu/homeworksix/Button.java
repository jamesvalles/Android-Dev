package csc472.depaul.edu.homeworksix;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;

public class Button extends android.support.v7.widget.AppCompatButton {
    public Button(Context context, int drawable) {
        super(context);
        createButton(drawable);
    }

    public Button(Context context, AttributeSet attrs, int drawable) {
        super(context, attrs);
        createButton(drawable);
    }

    public Button(Context context, AttributeSet attrs, int defStyleAttr, int drawable) {
        super(context, attrs, defStyleAttr);
        createButton(drawable);
    }

    private void createButton(int drawable) {
        setBackgroundResource(drawable);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.CENTER;
        params.width = ViewGroup.LayoutParams.WRAP_CONTENT;
        params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        setLayoutParams(params);
    }
}
