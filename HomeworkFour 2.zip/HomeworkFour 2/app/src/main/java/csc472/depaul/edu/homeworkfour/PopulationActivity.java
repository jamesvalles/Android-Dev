package csc472.depaul.edu.homeworkfour;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PopulationActivity extends AppCompatActivity
{
    public static TextView population = null;//a global static variable

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        //TODO: Uncomment this to see what thread is running
        //Main thread running here
        Log.v("THREAD_NAME : PopulationActivity: onCreate", Thread.currentThread().getName());

        super.onCreate(savedInstanceState);
        setContentView(R.layout.population_activity);

        final Button startPopulation = findViewById(R.id.startPopulationCount);
        if (startPopulation != null)
        {
            startPopulation.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    startPopulationCount();
                }
            });
        }

        population = findViewById(R.id.population);
        if (population != null)
        {
            population.setText(Long.toString((long)SharedData.getSharedData().getPopulation()));
        }
    }

    private void startPopulationCount()
    {
        PopulationThread.getPopulationThread().start();
    }

    public static void populationUpdated()
    {
        //TODO: Look at the thread name that is being logged - is it the main thread?
        //remember 'public' and static methods can easily be executed from any thread.
        //static methods can be executed any population without needing to be instantiated.

        //TODO: Uncomment this to see what thread is running
        //population thread running
        Log.v("THREAD_NAME : PopulationActivity: populationUpdated", Thread.currentThread().getName());

        //put a break point here - open your debug pane - go to debugger / threads
        //what thread is executing?
        if (population != null)
        {
            //TODO: Issue #3 What thread is executing?  Is it the main thread? Is this legal?
       //    population.setText(Long.toString((long)SharedData.getSharedData().getPopulation()));
        }

        //TODO: Issue #4 At this point what thread is executing? \
        //The method below will ENSURE we are on the main thread but you'll need to step into it to fix it
        updatePopulationOnMainThread();
    }

    private static void updatePopulationOnMainThread()
    {
        //TODO: Uncomment the code below and look at the thread name that is being logged - we are still on 'PopulationThread'
        //this is on population thread
         Log.v("THREAD_NAME: PopulationActivity: updatePopulationOnMainThread", Thread.currentThread().getName());

        //TODO: Issue #5 : This will trigger a message on the main thread/queue - uncoment and give it a try
        mainThreadHandler.sendEmptyMessage(0);
    }

    public static Handler mainThreadHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            //TODO: Uncomment the code below look at the thread name that is being logged - is it the main thread?
            //yes main thread.
             Log.v("THREAD_NAME: PopulationActivity: mainThreadHandler", Thread.currentThread().getName());

            //the line below will set your text
            population.setText(Long.toString((long)SharedData.getSharedData().getPopulation()));
        }
    };
}
