package csc472.depaul.edu.homeworkfour;

import android.util.Log;

import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class TimeThread implements Runnable
{
	private boolean started  = false;
	private static TimeThread timeThread = null;

	static
	{
		timeThread = new TimeThread();
	}

	private TimeThread()
	{
	}

	public static TimeThread getTimeThread()
	{
		return timeThread;
	}

	public synchronized void start()
	{
		//TODO: Uncomment the code below look at the thread name that is being logged - is it the main thread?
		//main thread running
		 Log.v("THREAD_NAME: TimeThread: start", Thread.currentThread().getName());

		if (started == false)
		{
			started = true;

			ScheduledThreadPoolExecutor scheduler = new ScheduledThreadPoolExecutor(1, new NamedThreadFactory("TimeThread"));
			if (scheduler != null)
			{
				scheduler.scheduleAtFixedRate(this, 0, 1, TimeUnit.SECONDS);
			}
		}
	}

	@Override
	public void run()
	{
		//TODO: Uncomment the code below look at the thread name that is being logged - is it the main thread?
		//no. its time thread.
		 Log.v("THREAD_NAME: TimeThread: run", Thread.currentThread().getName());

		try
		{
			SharedData.getSharedData().incrementTime();

			//TODO: Issue #1 - time is an UI element it needs updated on the main thread
			//TODO: Is this call legal?  If not you should delete it and find another way!
			//TimeActivity.time.setText(Long.toString(SharedData.getSharedData().getTime()));


			//TODO: Issue #2 -  if the above call is illegal then try calling a method in the time activity
			//TODO: to better understand what thread is running - you can use the one below
			TimeActivity.timeUpdated();
		}
		catch (Exception e)
		{
			Log.e("THREAD_NAME: TimeActivity: run", e.getMessage());
		}
	}
}

