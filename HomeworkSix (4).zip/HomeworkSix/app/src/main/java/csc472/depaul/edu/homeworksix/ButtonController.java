package csc472.depaul.edu.homeworksix;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.LinearLayout;

public class ButtonController extends LinearLayout {

    public ButtonController(Context context) {
        super(context);
        addInflatorLayout(context);
    }

    public ButtonController(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        addInflatorLayout(context);
    }

    public ButtonController(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        addInflatorLayout(context);
    }

    private void addInflatorLayout(Context context) {
        ButtonController.LayoutParams params = new ButtonController.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.width = ViewGroup.LayoutParams.WRAP_CONTENT;
        params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        setLayoutParams(params);
        addView(new Button(context, R.drawable.button_blue));
        addView(new Button(context, R.drawable.button_red));
        addView(new Button(context, R.drawable.button_yellow));
        addView(new Button(context, R.drawable.button_green));

    }
}
