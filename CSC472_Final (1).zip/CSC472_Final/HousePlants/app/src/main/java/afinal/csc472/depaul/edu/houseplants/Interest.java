package afinal.csc472.depaul.edu.houseplants;

public enum  Interest {
    bonsai,
    cleanairplant,
    ground,
    flowering,
    hanging,
    officeplants
}

